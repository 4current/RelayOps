
# ADR-0002: Internal message representation using MessageMeta
Date: 2026-02-16
Status: Accepted

## Context
RelayOps must support multiple transports including Winlink and Pat.

## Decision
Define an internal MessageMeta structure containing:
- Transport
- Session
- Constraints
- AutomationProfile

Transport adapters convert between MessageMeta and external formats.

## Consequences
Positive:
- transport abstraction
- extensibility

Negative:
- requires conversion logic
