
# ADR-0003: Use Pat CLI for Winlink transport
Date: 2026-02-18
Status: Accepted

## Context
Winlink Express is GUI driven and difficult to automate.

## Decision
Use Pat CLI for automated message transport.

## Consequences
Positive:
- automation friendly
- cross platform

Negative:
- requires Pat installation
